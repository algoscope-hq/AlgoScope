# AlgoScope

AlgoScope is an interactive web application designed to visualize various algorithms, including sorting, searching, and graph traversals. It aims to help learners and developers understand complex algorithmic concepts through step-by-step animations and a user-friendly interface.

## Project Overview

-   **Type:** Web Application (React/Vite)
-   **Purpose:** Educational tool for algorithm visualization.
-   **Key Technologies:**
    -   **Frontend:** React 19, Tailwind CSS v4, Framer Motion
    -   **UI Components:** Flowbite React, MUI Material
    -   **Routing:** React Router DOM v7
    -   **Build Tool:** Vite
    -   **Visualization:** D3.js (inferred from README, though not explicitly in package.json dependencies, likely managed via custom logic or bundled scripts)

### Architecture

-   **Entry Point:** `src/main.jsx` initializes the React app.
-   **Routing:** `src/App.jsx` handles client-side routing using `createBrowserRouter`. Key routes include:
    -   `/`: Home page
    -   `/sort`: Sorting algorithms
    -   `/search`: Graph searching algorithms (BFS/DFS)
    -   `/spath`: Shortest path algorithms
    -   `/ldssearch`: Linear/Binary search on arrays
    -   `/about`: About page
-   **Components:** Located in `src/components/`, organized by feature (e.g., `sortingAlgo/`, `searchAlgo/`).

## Building and Running

The project uses `npm` for dependency management and scripts.

### Key Commands

-   **Install Dependencies:**
    ```bash
    npm install
    ```
-   **Start Development Server:**
    ```bash
    npm run dev
    ```
    Access the app at `http://localhost:5173`.
-   **Build for Production:**
    ```bash
    npm run build
    ```
    Output is generated in the `dist/` directory.
-   **Preview Production Build:**
    ```bash
    npm run preview
    ```
-   **Lint Code:**
    ```bash
    npm run lint
    ```

## Development Conventions

### Coding Style

-   **Formatting:** Prettier is configured with:
    -   No semicolons (`semi: false`)
    -   Single quotes (`singleQuote: true`)
    -   2-space indentation (`tabWidth: 2`)
    -   Trailing commas (`trailingComma: "es5"`)
-   **Linting:** ESLint is used with standard React hooks and refresh plugins.
-   **Imports:** Path alias `@/` maps to `./src/`.

### Component Structure

-   Components are functional and use React Hooks (`useState`, `useEffect`).
-   Styling relies heavily on Tailwind CSS utility classes.
-   Animations are implemented using `framer-motion` (e.g., page transitions in `App.jsx`, element animations in `Home.jsx`).
-   Feature-specific logic (e.g., visualization algorithms) is often co-located with the UI components in subdirectories like `src/components/sortingAlgo/`.
